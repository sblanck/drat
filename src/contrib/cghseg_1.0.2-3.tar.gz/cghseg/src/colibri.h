#include "liste.h"
#include "usefullReadAndWrite.h"

void colibri_c (double *profil, int *nbi, int *Kmaxi, double *mini, double *maxi, int *origine, double *cout_n);

