#ifndef CGHSEG_CGHSEG_TYPES_H
#define CGHSEG_CGHSEG_TYPES_H

#include "numlib.h"

typedef struct {
  numlib_vector *phi;
  numlib_matrix *rupt;
    
} param_struct;

#endif
